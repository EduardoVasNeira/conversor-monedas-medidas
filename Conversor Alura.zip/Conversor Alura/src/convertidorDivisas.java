
public class convertidorDivisas {
	
	//Clase que contiene como atributos el precio actual de las divisas segun el precio chileno
	
	private double dolar = 909.85;
	private double euro = 991.51;
	private double libraEsterlina = 1180.35;
	private double yen = 5.75;
	private double wonSul = 0.66;

	
	public convertidorDivisas() {
	}
	
	//Metodos de conversion para cada tipo de moneda
	
	public double convertidorCOPaUSD(double COP){
		
		double conversion = (COP*1)/dolar;
		
		return conversion;
	}
	
	public double convertidorCOPaEUR(double COP){
		
		double conversion = (COP*1)/euro;
		
		return conversion;
	}

	public double convertidorCOPaGBP(double COP){
	
		double conversion = (COP*1)/libraEsterlina;
	
		return conversion;
	}
	
	public double convertidorCOPaJPY(double COP){
	
		double conversion = (COP*1)/yen;
	
		return conversion;
	}

	public double convertidorCOPaKRW(double COP){
	
		double conversion = (COP*1)/wonSul;
	
		return conversion;
	}
	
	public double convertidorUSDaCop(double USD){
	
		double conversion = USD*dolar;
		
		return conversion;
	}
	
	public double convertidorEURaCOP(double EUR){
		
		double conversion = EUR*euro;
		
		return conversion;
	}

	public double convertidorGBPaCOP(double GBP){
	
		double conversion = GBP*libraEsterlina;
	
		return conversion;
	}
	
	public double convertidorJPYaCop(double JPY){
	
		double conversion = JPY*yen;
	
		return conversion;
	}

	public double convertidorKRWaCOP(double KRW){
	
		double conversion = KRW*wonSul;
	
		return conversion;
	}
	
}
