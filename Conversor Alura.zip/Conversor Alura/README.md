


 Proyecto de conversión Oracle - Alura

 Descripción

El codigo en cuestión permite ingresar datos numeros para posteriormente realizar la conversion al tipo de dato que el usuario requiera. El codigo cuenta con dos funcionalidades, la primera, siendo el conversor de monedas y la segunda, conversor de medidas teniendo como unidad de medida central al metro.

1.-  Caracteristicas
Conversion de monedas
	Conversión de CLP a USD
	Conversión de CLP a EUR
	Conversión de CLP a JPY
	Conversión de CLP a GBP
	Conversión de CLP a KRW
	Conversión de USD a CLP
	Conversión de EUR a CLP
	Conversión de JPY a CLP
	Conversión de GBP a CLP
	Conversión de KRW a CLP
Conversion de medidas
	Conversión de KM a M
	Conversión de HM a M
	Conversión de DM a M
	Conversiónr de CM a M
	Conversión de MM a M
	Conversión de M a KM
	Conversión de M a HC
	Conversión de M a DC
	Conversión de M a CM
	Conversión de M a MM
